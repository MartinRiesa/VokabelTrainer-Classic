import poster
import station_description

def evaluate_answer(game, selected_answer, button):
    """
    Bewertet eine Nutzer-Antwort. Bei korrekter Antwort wird automatisch
    zur nächsten Frage gewechselt. Nur bei falscher Antwort erscheint der
    "Weiter"-Button.
    """
    if selected_answer is None:
        return

    # Richtigkeitsprüfung
    correct_answer = game.vocab_pool[0][1] == selected_answer

    # Status-Updates und Button-Deaktivierung
    button_style = "Correct.TButton" if correct_answer else "Wrong.TButton"
    button.config(style=button_style)
    game.streak = game.streak + 1 if correct_answer else 0
    for b in game.btns:
        b.config(state="disabled")

    question = game.vocab_pool[0][0]

    if correct_answer:
        # Statistik aktualisieren
        if question in game.stats:
            game.stats[question].n += 1
        # Vokabel aus Pool entfernen
        game.vocab_pool.pop(0)
        # Levelende?
        if not game.vocab_pool:
            poster.update_sharpen(game)
            station_description.show_description(game)
        else:
            # Automatisch nächste Frage nach kurzer Verzögerung
            game.root.after(1200, lambda: __import__('fragenlogik').next_question(game))
    else:
        # Falsche Antwort → Weiter-Button einblenden
        game.next_btn.pack(pady=10)
