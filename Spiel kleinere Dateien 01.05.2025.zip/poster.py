# poster.py

from config import CURTAIN_FILE, BANNER_W, BANNER_H
from poster_loader import load_poster_image, display_poster
from poster_effects import blur_image, sharpen_image
from PIL import Image, ImageTk

def load_poster(game, level):
    """
    Lade und zeige das Poster für `level`:
    Poster-Dateien liegen im selben Ordner und heißen z.B. poster_1.png, poster_2.png, …
    """
    poster_path = CURTAIN_FILE.parent / f"poster_{level}.png"
    photo = load_poster_image(poster_path, (BANNER_W, BANNER_H))
    display_poster(game, photo)

def update_blur(game, radius=10):
    """
    Wendet Blur auf das aktuelle Poster an und zeigt es an.
    """
    # Original-Pfad anhand aktuellen Levels bestimmen
    poster_path = CURTAIN_FILE.parent / f"poster_{game.level}.png"
    # Bild laden als PIL
    pil_img = Image.open(poster_path).resize((BANNER_W, BANNER_H), Image.LANCZOS)
    # Blur anwenden
    blurred_pil = blur_image(pil_img, radius)
    # Umwandeln und anzeigen
    blurred_photo = ImageTk.PhotoImage(blurred_pil)
    display_poster(game, blurred_photo)

def update_sharpen(game):
    """
    Wendet Schärfen auf das aktuelle Poster an und zeigt es an.
    """
    poster_path = CURTAIN_FILE.parent / f"poster_{game.level}.png"
    pil_img = Image.open(poster_path).resize((BANNER_W, BANNER_H), Image.LANCZOS)
    sharp_pil = sharpen_image(pil_img)
    sharp_photo = ImageTk.PhotoImage(sharp_pil)
    display_poster(game, sharp_photo)
