"""
initialisierung.py – Laden der Spieldaten und Aufbau der grafischen Oberfläche zu Spielbeginn.
"""

import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

from config import (
    BASE_PATH, EXCEL_STATIONS,
    # BEGIN CHANGES: replaced EXCEL_VOCAB with CSV_VOCAB
    CSV_VOCAB,
    # END CHANGES
    BANNER_W, BANNER_H, MAP_FILE, TRAIN_ICON,
    MAP_SMALL
)
from hilfsfunktionen import geo_to_pixel


def load_game_data():
    """
    Lädt die Stations- und Vokabeldaten aus den Excel-Dateien.
    Gibt die Liste der Stationen sowie die Vokabelblöcke pro Level zurück.
    """
    # Stationen
    df_st = pd.read_excel(EXCEL_STATIONS, header=None)
    stations = []
    for latlon, name in zip(df_st.iloc[1:, 2], df_st.iloc[1:, 3]):
        try:
            lat, lon = map(float, str(latlon).split(","))
            stations.append({"name": str(name), "lat": lat, "lon": lon})
        except ValueError:
            continue

    # Vokabeln
    # BEGIN CHANGES: read vocabulary from CSV file instead of Excel
    df_vocab = pd.read_csv(CSV_VOCAB, sep=';', usecols=[0, 1], header=None, skiprows=1)
    # END CHANGES
    vocab_pairs = list(zip(df_vocab[0].astype(str), df_vocab[1].astype(str)))
    blocks = len(vocab_pairs) // 7
    total_levels = min(len(stations), blocks)
    stations = stations[:total_levels]
    vocab_levels = [vocab_pairs[i*7:(i+1)*7] for i in range(total_levels)]

    return stations, vocab_levels


def init_game_state(game, stations, vocab_levels):
    """
    Initialisiert den Spielzustand:
    - Setzt Level-Zähler, erste Vokabelliste und Statistik.
    - Legt den kumulativen Pool an und füllt ihn mit Level-1-Vokabeln.
    """
    game.total_levels = len(vocab_levels)
    game.stations     = stations
    game.vocab_levels = vocab_levels

    if not game.stations:
        messagebox.showerror("Fehler", "Keine Stationen gefunden.")
        game.root.quit()
        return False

    # Startzustand
    game.level      = 1
    # kumulativer Pool
    game.vocab_pool = list(game.vocab_levels[0])
    # aktuelles Vokabel-Set (UI, aber Fragen verwenden pool)
    game.vocab      = list(game.vocab_pool)

    from stats_game import Stat
    # Statistik über den Pool
    game.stats  = {de: Stat() for de, _ in game.vocab_pool}
    game.streak = 0
    game.last_de = None

    return True


def build_ui(game):
    """
    Baut die grafische Benutzeroberfläche (GUI) des Spiels auf:
    Banner-Bereich mit Blur-Poster, Infozeile, Spielfläche und Minikarte.
    """
    # Fenster-Grundeinstellungen
    game.root.title("Vokabellernspiel – Deutschland-Reise")
    game.root.geometry("1024x860")
    game.root.configure(bg="#eef4fb")

    # 1) Banner-Bereich (Blur-Poster)
    banner_frame = ttk.Frame(game.root, padding=10, style="Bg.TFrame")
    banner_frame.pack()
    game.canvas = tk.Canvas(banner_frame, width=BANNER_W, height=BANNER_H, highlightthickness=0)
    game.canvas.pack()
    # Platzhalter für Poster
    game.poster_item = game.canvas.create_image(0, 0, anchor="nw")

    # 2) Infozeile (Level-Anzeige)
    info_frame = ttk.Frame(game.root, padding=5, style="Bg.TFrame")
    info_frame.pack()
    game.level_var = tk.StringVar(value=f"Station 1: {game.stations[0]['name']}")
    ttk.Label(info_frame, textvariable=game.level_var,
              font=("Arial", 14, "bold"), style="Bg.TLabel").pack(side="left", padx=12)

    # 3) Spielfläche (Frage + Antworten)
    play_frame = ttk.Frame(game.root, padding=10, style="Bg.TFrame")
    play_frame.pack(expand=True, fill="both")

    # Fragebereich
    game.qvar = tk.StringVar()
    question_row = ttk.Frame(play_frame, style="Bg.TFrame")
    question_row.pack(pady=(30, 15))
    ttk.Label(question_row, textvariable=game.qvar,
              font=("Arial", 28, "bold"), style="Bg.TLabel").pack(side="left")

    # Lautsprecher-Button
    from tts import speak_current_word
    speaker_btn = ttk.Button(question_row, text="🔊", width=3,
                             command=lambda: speak_current_word(game))
    speaker_btn.pack(side="left", padx=10)
    game.speaker_btn = speaker_btn

    # Antwort-Buttons
    game.btns = [ttk.Button(play_frame, style="TButton") for _ in range(4)]
    for btn in game.btns:
        btn.pack(pady=8)

    # Weiter-Button (für falsche Antworten)
    from fragenlogik import after_wrong
    game.next_btn = ttk.Button(play_frame, text="Weiter",
                               command=lambda: after_wrong(game))

    # 4) Mini-Karte (unten rechts)
    w_small, h_small = MAP_SMALL
    game.map_canvas = tk.Canvas(game.root, width=w_small, height=h_small,
                                highlightthickness=1, bd=1)
    game.map_canvas.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-10)

    # Karte und Zug-Icon laden
    game.map_tk = ImageTk.PhotoImage(
        Image.open(MAP_FILE).resize((w_small, h_small), Image.LANCZOS),
        master=game.root
    )
    game.map_canvas.create_image(0, 0, anchor="nw", image=game.map_tk)

    game.train_tk = ImageTk.PhotoImage(
        Image.open(TRAIN_ICON).convert("RGBA").resize((24, 24), Image.LANCZOS),
        master=game.root
    )
    lat0, lon0 = game.stations[0]['lat'], game.stations[0]['lon']
    x0, y0 = geo_to_pixel(lat0, lon0, map_w=w_small, map_h=h_small)
    game.marker = game.map_canvas.create_image(x0, y0, anchor="center", image=game.train_tk)
