# poster.py

from config import CURTAIN_FILE, BANNER_W, BANNER_H
from poster_loader import load_poster_image, display_poster
from poster_effects import blur_image, sharpen_image
from PIL import Image, ImageTk
import os

def load_poster(game, level):
    """
    Lade und zeige das Poster für `level`:
    Poster-Dateien heißen poster_1.png, poster_2.png, … im selben Verzeichnis wie CURTAIN_FILE.
    Zeigt bei fehlender Datei weiterhin den grauen Platzhalter.
    """
    poster_path = CURTAIN_FILE.parent / f"poster_{level}.png"
    if poster_path.exists():
        try:
            photo = load_poster_image(poster_path, (BANNER_W, BANNER_H))
            display_poster(game, photo)
            return
        except Exception:
            pass
    # Fallback: grauer Platzhalter
    game.canvas.delete("all")
    game.canvas.configure(bg="#ccc")
    game.canvas.create_text(BANNER_W//2, BANNER_H//2,
                            text=f"Kein Poster für Level {level}",
                            font=("Arial", 24), fill="#666")
    # Neuen poster_item für künftige Updates anlegen
    game.poster_item = game.canvas.create_image(0, 0, anchor="nw")

def update_blur(game, radius=10):
    """
    Wendet Blur auf das aktuelle Poster an und zeigt es an.
    Falls das Poster nicht geladen ist, bleibt der Placeholder bestehen.
    """
    # Für Placeholder oder fehlende Datei nichts tun
    poster_path = CURTAIN_FILE.parent / f"poster_{game.level}.png"
    if not poster_path.exists():
        return
    try:
        pil_img = Image.open(poster_path).resize((BANNER_W, BANNER_H), Image.LANCZOS)
        blurred = blur_image(pil_img, radius)
        photo = ImageTk.PhotoImage(blurred)
        display_poster(game, photo)
    except Exception:
        pass

def update_sharpen(game):
    """
    Wendet Schärfen auf das aktuelle Poster an und zeigt es an.
    """
    poster_path = CURTAIN_FILE.parent / f"poster_{game.level}.png"
    if not poster_path.exists():
        return
    try:
        pil_img = Image.open(poster_path).resize((BANNER_W, BANNER_H), Image.LANCZOS)
        sharp = sharpen_image(pil_img)
        photo = ImageTk.PhotoImage(sharp)
        display_poster(game, sharp)
    except Exception:
        pass
