"""
levelwechsel.py – steuert den Übergang zum nächsten Level mit Poster-, Karten- und Button-Logik.
"""

import poster
from stats_game import Stat
import fragenlogik
import uebersichtskarte
from hilfsfunktionen import geo_to_pixel
from config import MAP_SMALL
from tkinter import messagebox

def level_up(game):
    # 1) Spielende prüfen
    if game.level >= game.total_levels:
        messagebox.showinfo("Ende", "Alle Stationen geschafft!")
        game.root.quit()
        return

    # 2) Übersichtskarte anzeigen (modal mit 'Weiter'-Button)
    uebersichtskarte.show_overview(game)

    # 3) Nächstes Level vorbereiten
    game.level += 1

    # Vokabel-Pool erweitern
    neue_vocab = game.vocab_levels[game.level - 1]
    game.vocab_pool += neue_vocab
    game.vocab = list(game.vocab_pool)

    # Statistik zurücksetzen / neu aufbauen
    game.stats = {q: Stat() for q, _ in game.vocab_pool}
    game.streak = 0
    game.last_question = None

    # Poster und GUI-Labels aktualisieren
    poster.load_poster(game, game.level)
    station_name = game.stations[game.level - 1]['name']
    game.level_var.set(f"Station {game.level}: {station_name}")

    # Koordinaten aktualisieren
    lat, lon = game.stations[game.level - 1]['lat'], game.stations[game.level - 1]['lon']
    game.coord_var.set(f"{lat:.4f}, {lon:.4f}")

    # Minikarte verschieben und in den Vordergrund heben
    w, h = MAP_SMALL
    x, y = geo_to_pixel(lat, lon, map_w=w, map_h=h)
    game.map_canvas.coords(game.marker, x, y)
    game.root.tk.call('raise', game.map_canvas._w)

    # 4) Quiz starten (nach Übersicht und Aktualisierung)
    fragenlogik.next_question(game)
