"""
uebersichtskarte.py – Anzeige der Übersichtskarte mit bereits geschafften Stationen.
"""

import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from config import MAP_FILE, MAP_LARGE, DOT_RADIUS
import hilfsfunktionen
import fragenlogik

def show_overview(game):
    """
    Öffnet ein Fenster mit einer großen Deutschlandkarte, markiert alle abgeschlossenen Stationen 
    und die aktuelle Position. Über einen "Weiter"-Button kann der Spieler zur nächsten Frage gelangen.
    """
    # Neues modales Fenster für die Übersichtskarte
    win = tk.Toplevel(game.root)
    win.title("Stations-Übersicht")
    w_big, h_big = MAP_LARGE
    win.geometry(f"{w_big}x{h_big}")
    win.resizable(False, False)
    # Canvas für die große Karte erstellen
    canvas = tk.Canvas(win, width=w_big, height=h_big, highlightthickness=0)
    canvas.pack()
    # Hintergrundkarte laden (angepasst an die Fenstergröße)
    img_big = ImageTk.PhotoImage(Image.open(MAP_FILE).resize((w_big, h_big), Image.LANCZOS), master=win)
    canvas.create_image(0, 0, anchor="nw", image=img_big)
    canvas.bg_img = img_big  # Referenz halten, damit das Bild nicht vorzeitig gelöscht wird
    # Bereits abgeschlossene Stationen als grüne Punkte markieren
    for station in game.stations[:game.level - 1]:
        x, y = hilfsfunktionen.geo_to_pixel(station['lat'], station['lon'], map_w=w_big, map_h=h_big)
        canvas.create_oval(x - DOT_RADIUS, y - DOT_RADIUS, x + DOT_RADIUS, y + DOT_RADIUS,
                           fill="#4caf50", outline="")
    # Aktuelle Station mit Zug-Icon markieren
    lat_cur = game.stations[game.level - 1]['lat']; lon_cur = game.stations[game.level - 1]['lon']
    x_cur, y_cur = hilfsfunktionen.geo_to_pixel(lat_cur, lon_cur, map_w=w_big, map_h=h_big)
    canvas.train_img = game.train_tk  # Zug-Icon aus dem Hauptfenster weiterverwenden
    canvas.create_image(x_cur, y_cur, anchor="center", image=canvas.train_img)
    # "Weiter"-Button zentriert auf der Karte platzieren (Fenster schließen und nächste Frage)
    btn = ttk.Button(win, text="Weiter", command=lambda: (win.destroy(), fragenlogik.next_question(game)))
    canvas.create_window(w_big // 2, h_big // 2, window=btn)
    # Modalität: Eingaben blockieren, bis Fenster geschlossen ist
    win.grab_set()
    game.root.wait_window(win)
