"""
fragenlogik.py – Logik für Fragen und Antworten mit Blur-Feedback und direktem Level-Up.
"""

import random
import datetime as dt

from config import STREAK_GOAL, SPACING_MIN
import poster
import levelwechsel

def next_question(game):
    for b in game.btns:
        b.state(["!disabled"])
        b.configure(style="TButton")
    game.next_btn.pack_forget()

    choices = [pair for pair in game.vocab_pool if pair[0] != game.last_de]
    if not choices:
        choices = game.vocab_pool

    de, en = random.choice(choices)
    game.last_de = de
    game.de, game.en = de, en

    stat = game.stats[de]
    # 1) gespeicherte falsche Distraktoren
    opts = stat.wrong_choices.copy()
    # 2) neue Distraktoren
    pool_wrong = [x for _, x in game.vocab_pool if x != en and x not in opts]
    random.shuffle(pool_wrong)
    opts += pool_wrong[: max(0, 3 - len(opts))]
    # 3) richtige Antwort hinzufügen und mischen
    opts.append(en)
    random.shuffle(opts)

    game.qvar.set(de)
    for btn, txt in zip(game.btns, opts):
        btn.configure(text=txt, command=lambda t=txt, b=btn: evaluate(game, t, b))


def evaluate(game, answer: str, btn):
    stat = game.stats[game.de]
    now = dt.datetime.now()

    if answer == game.en:
        # Richtig beantwortet: Streak erhöhen
        game.streak += 1

        # Leitner-Update
        stat.i = min(
            (0 if stat.n == 0 else (1 if stat.n == 1 else stat.i + 1)),
            len(SPACING_MIN) - 1
        )
        stat.n += 1
        stat.due = now + dt.timedelta(minutes=SPACING_MIN[stat.i])

        # alte falsche Distraktoren löschen
        stat.wrong_choices.clear()

        # Wenn Streak-Ziel erreicht, Level-Up direkt auslösen
        if game.streak >= STREAK_GOAL:
            levelwechsel.level_up(game)
            return

        # ansonsten Bild schärfen und nächste Frage
        poster.update_blur(game)
        next_question(game)

    else:
        # Falsch beantwortet
        for b in game.btns:
            txt = b.cget("text")
            if txt == game.en:
                b.configure(style="Success.TButton")
            elif b is btn:
                b.configure(style="Danger.TButton")
            b.state(["disabled"])

        # Streak & Leitner-Reset
        game.streak = 0
        stat.n = 0
        stat.i = 0
        stat.due = now + dt.timedelta(minutes=SPACING_MIN[0])

        # falschen Distraktor speichern
        stat.wrong_choices = [answer]

        # Bild verwischen und Weiter-Button anzeigen
        poster.update_blur(game)
        game.next_btn.pack(pady=20)


def after_wrong(game):
    next_question(game)
