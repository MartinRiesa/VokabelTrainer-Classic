"""
poster.py – Funktionen zum Laden des Posters und Steuerung des Blur-Effekts.
"""

from pathlib import Path
from tkinter import messagebox
from PIL import Image, ImageTk, ImageFilter
from config import BASE_PATH, BANNER_W, BANNER_H, STREAK_GOAL

# Maximaler Blur-Radius bei 0 Streak
MAX_BLUR_RADIUS = 15

def load_poster(game, lvl: int):
    """
    Lädt das passende Posterbild unverblurrt und speichert die Original-Instanz.
    Anschließend wendet den initialen Blur-Grad an.
    """
    def poster_path(n: int) -> Path:
        return BASE_PATH / f"{n}.jpg"

    while lvl > 0 and not poster_path(lvl).exists():
        lvl -= 1
    if lvl == 0:
        messagebox.showerror("Poster fehlt", "Keine Posterdatei gefunden.")
        game.root.quit()
        return

    game.poster_orig = Image.open(poster_path(lvl)).resize((BANNER_W, BANNER_H), Image.LANCZOS)
    update_blur(game)


def update_blur(game):
    """
    Wendet auf das gespeicherte Originalbild einen Blur-Filter an,
    dessen Radius mit steigendem Streak geringer wird.
    """
    ratio = min(game.streak, STREAK_GOAL) / STREAK_GOAL
    radius = MAX_BLUR_RADIUS * (1 - ratio)

    blurred = game.poster_orig.filter(ImageFilter.GaussianBlur(radius))

    game.poster_tk = ImageTk.PhotoImage(blurred, master=game.root)
    game.canvas.itemconfig(game.poster_item, image=game.poster_tk)
