# hilfsfunktionen.py

from config import LAT_MIN, LAT_MAX, LON_MIN, LON_MAX

def geo_to_pixel(lat: float, lon: float, *, map_w: int, map_h: int):
    x = (lon - LON_MIN) / (LON_MAX - LON_MIN) * map_w
    y = (LAT_MAX - lat) / (LAT_MAX - LAT_MIN) * map_h
    return int(x), int(y)
