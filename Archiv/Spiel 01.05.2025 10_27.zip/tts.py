"""
tts.py – Modul für Text-to-Speech-Funktionen.
Enthält Initialisierung der TTS-Engine und Funktionen zum Sprechen.
"""

import threading
import pyttsx3

def init_tts():
    """
    Initialisiert die TTS-Engine und stellt, falls verfügbar, auf eine deutsche Stimme um.
    """
    engine = pyttsx3.init()
    for v in engine.getProperty("voices"):
        # Je nach Plattform kann languages ein bytes-Array oder str sein
        langs = [l.decode() if isinstance(l, bytes) else l for l in getattr(v, "languages", [])]
        if any("de" in l.lower() for l in langs) or "german" in v.name.lower():
            engine.setProperty("voice", v.id)
            break
    return engine

def speak_current_word(game):
    """
    Spricht das aktuell angezeigte deutsche Wort (game.de) über die TTS-Engine.
    Startet die Sprachausgabe in einem eigenen Thread, um die GUI nicht zu blockieren.
    """
    text = getattr(game, "de", None)
    if not text:
        return
    # In eigenem Thread sprechen, damit die GUI nicht blockiert
    threading.Thread(target=speak_text, args=(game.tts, text), daemon=True).start()

def speak_text(engine, text: str):
    """
    Spricht den gegebenen Text über die angegebene TTS-Engine.
    Falls die Engine ausgelastet ist, wird ein zweites Engine-Objekt verwendet.
    """
    try:
        engine.say(text)
        engine.runAndWait()
    except RuntimeError:
        # Fallback: neues Engine-Objekt nutzen, falls die Haupt-Engine parallel verwendet wird
        temp_engine = pyttsx3.init()
        temp_engine.say(text)
        temp_engine.runAndWait()
