"""
spiel.py – Hauptmodul des Spiels, initialisiert das Spiel und orchestriert die verschiedenen Module.
"""

import tts
import poster
import fragenlogik
import initialisierung

class Spiel:
    def __init__(self, root):
        self.root = root

        # 1) TTS-Engine initialisieren
        self.tts = tts.init_tts()

        # 2) Spieldaten laden
        stations, vocab_levels = initialisierung.load_game_data()

        # 3) Spielzustand initialisieren (Level, Pool, Stats etc.)
        success = initialisierung.init_game_state(self, stations, vocab_levels)
        if not success:
            return

        # 4) GUI aufbauen – hier werden self.canvas, self.poster_item etc. erzeugt
        initialisierung.build_ui(self)

        # 5) Erstes Poster laden und Frage starten
        poster.load_poster(self, self.level)
        fragenlogik.next_question(self)
