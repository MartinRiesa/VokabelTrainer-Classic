# stats_game.py – Enthält die Definition der Klasse Stat mit Speicherung
#                der zuletzt falsch gewählten Distraktoren.

import datetime as dt

class Stat:
    def __init__(self):
        # Leitner-System
        self.EF = 2.5        # Easiness-Faktor (derzeit ungenutzt)
        self.n = 0           # Anzahl korrekt beantworteter Male
        self.i = 1           # Index in SPACING_MIN
        self.due = dt.datetime.now()  # nächster Fälligkeitstermin

        # Speicherung falscher Distraktoren
        # hier wird die letzte(n) falsch geklickte(n) Übersetzung(en) aufbewahrt
        self.wrong_choices = []
