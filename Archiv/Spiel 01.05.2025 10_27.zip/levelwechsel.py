"""
levelwechsel.py – Behandlung des Levelaufstiegs und Pool-Erweiterung mit Blur-Poster.
"""

from tkinter import messagebox
from config import MAP_SMALL
from stats_game import Stat
import poster
import animation
import uebersichtskarte as overview
from hilfsfunktionen import geo_to_pixel

def level_up(game):
    """
    Führt den Aufstieg ins nächste Level durch:
    1) Level hochzählen
    2) Prüfen auf Spielende
    3) Vokabel-Pool erweitern
    4) Statistik neu aufbauen
    5) Streak und letzte Vokabel zurücksetzen (wichtig vor load_poster)
    6) Poster laden (setzt den initialen Blur basierend auf streak=0)
    7) Stationsanzeige aktualisieren
    8) Zug-Icon animieren
    9) Übersichtskarte anzeigen
    """
    prev_index = game.level - 1
    game.level += 1

    # 2) Spielende?
    if game.level > game.total_levels:
        messagebox.showinfo("Ende", "Alle Stationen geschafft!")
        game.root.quit()
        return

    # 3) Vokabel-Pool erweitern
    neue_vocab = game.vocab_levels[game.level - 1]
    game.vocab_pool += neue_vocab
    game.vocab = list(game.vocab_pool)

    # 4) Statistik neu aufbauen
    game.stats = { de: Stat() for de, _ in game.vocab_pool }

    # 5) Streak und letzte Vokabel zurücksetzen (vor Poster-Load!)
    game.streak = 0
    game.last_de = None

    # 6) Neues Poster laden (inkl. maximalen Blur bei streak=0)
    poster.load_poster(game, game.level)

    # 7) Stationsanzeige aktualisieren
    station_name = game.stations[game.level - 1]['name']
    game.level_var.set(f"Station {game.level}: {station_name}")

    # 8) Zug-Icon auf der Mini-Karte animieren
    lat_old, lon_old = game.stations[prev_index]['lat'], game.stations[prev_index]['lon']
    lat_new, lon_new = game.stations[game.level - 1]['lat'], game.stations[game.level - 1]['lon']
    x0, y0 = geo_to_pixel(lat_old, lon_old, map_w=MAP_SMALL[0], map_h=MAP_SMALL[1])
    x1, y1 = geo_to_pixel(lat_new, lon_new, map_w=MAP_SMALL[0], map_h=MAP_SMALL[1])
    animation.animate_marker(game, x0, y0, x1, y1)

    # 9) Hinweis und Übersichtskarte
    messagebox.showinfo("Station geschafft", f"Weiter nach {station_name}")
    overview.show_overview(game)
