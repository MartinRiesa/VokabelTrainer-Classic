# tts.py

import threading
import pyttsx3  # BEGIN CHANGES: TTS-Engine importiert

def init_tts():
    """
    Initialisiert und gibt die TTS-Engine zurück.
    """
    engine = pyttsx3.init()             # BEGIN CHANGES: init_tts-Funktion hinzugefügt
    engine.setProperty('rate', 150)     # Sprechgeschwindigkeit anpassen (optional)
    engine.setProperty('volume', 1.0)   # Lautstärke anpassen (optional)
    return engine                        # END CHANGES

def speak_text(engine, text):
    """
    Führt die Sprachausgabe durch.
    """
    engine.say(text)
    engine.runAndWait()

def speak_current_word(game):
    """
    Spricht das aktuell angezeigte Wort über die TTS-Engine.
    Startet die Sprachausgabe in einem eigenen Thread, um die GUI nicht zu blockieren.
    """
    text = getattr(game, "current_question", None)
    if not text:
        return
    threading.Thread(target=speak_text, args=(game.tts, text), daemon=True).start()
