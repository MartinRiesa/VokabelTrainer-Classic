import tkinter as tk  # GEÄNDERT: für die Sprachauswahl benötigt
from config import CSV_VOCAB  # GEÄNDERT: Pfad zur CSV-Datei importiert
from tkinter import messagebox  # GEÄNDERT: für Fehlermeldungen
import tts
import poster
import fragenlogik
import initialisierung

class Spiel:
    def __init__(self, root):
        self.root = root

        # 1) TTS-Engine initialisieren
        self.tts = tts.init_tts()

        # 1.5) Sprachen auswählen (Lernsprache und Muttersprache)  # GEÄNDERT: Auswahlfenster hinzugefügt
        with open(CSV_VOCAB, 'r', encoding='utf-8-sig') as f:
            header = f.readline().strip()
        languages = header.split(';')
        # Language selection window
        lang_win = tk.Toplevel(self.root)
        lang_win.title('Sprachauswahl')
        lang_win.grab_set()
        tk.Label(lang_win, text='Lernsprache:').pack(padx=5, pady=5)
        learn_var = tk.StringVar(value=languages[0])
        tk.OptionMenu(lang_win, learn_var, *languages).pack(padx=5, pady=5)
        tk.Label(lang_win, text='Muttersprache:').pack(padx=5, pady=5)
        native_var = tk.StringVar(value=languages[1])
        tk.OptionMenu(lang_win, native_var, *languages).pack(padx=5, pady=5)
        def on_ok():
            self.learn_lang = learn_var.get()
            self.native_lang = native_var.get()
            if self.learn_lang == self.native_lang:
                messagebox.showerror('Fehler', 'Lern- und Muttersprache müssen unterschiedlich sein.')
            else:
                lang_win.destroy()
        tk.Button(lang_win, text='OK', command=on_ok).pack(pady=10)
        self.root.wait_window(lang_win)

        # 2) Spieldaten laden
        stations, vocab_levels = initialisierung.load_game_data(self.learn_lang, self.native_lang)  # GEÄNDERT: gewählte Sprachen übergeben

        # 3) Spielzustand initialisieren (Level, Pool, Stats etc.)
        success = initialisierung.init_game_state(self, stations, vocab_levels)
        if not success:
            return

        # 4) GUI aufbauen – hier werden self.canvas, self.poster_item etc. erzeugt
        initialisierung.build_ui(self)

        # 5) Erstes Poster laden und Frage starten
        poster.load_poster(self, self.level)
        fragenlogik.next_question(self)

    def change_language(self):
        # Auswahl der Sprachen erneut anzeigen und Spiel zurücksetzen
        with open(CSV_VOCAB, 'r', encoding='utf-8-sig') as f:
            header = f.readline().strip()
        languages = header.split(';')
        lang_win = tk.Toplevel(self.root)
        lang_win.title('Sprachauswahl')
        lang_win.grab_set()
        tk.Label(lang_win, text='Lernsprache:').pack(padx=5, pady=5)
        learn_var = tk.StringVar(value=self.learn_lang)
        tk.OptionMenu(lang_win, learn_var, *languages).pack(padx=5, pady=5)
        tk.Label(lang_win, text='Muttersprache:').pack(padx=5, pady=5)
        native_var = tk.StringVar(value=self.native_lang)
        tk.OptionMenu(lang_win, native_var, *languages).pack(padx=5, pady=5)
        def on_ok():
            self.learn_lang = learn_var.get()
            self.native_lang = native_var.get()
            if self.learn_lang == self.native_lang:
                messagebox.showerror('Fehler', 'Lern- und Muttersprache müssen unterschiedlich sein.')
            else:
                lang_win.destroy()
        tk.Button(lang_win, text='OK', command=on_ok).pack(pady=10)
        self.root.wait_window(lang_win)
        # Spiel zurücksetzen mit neuen Sprachen
        stations, vocab_levels = initialisierung.load_game_data(self.learn_lang, self.native_lang)
        success = initialisierung.init_game_state(self, stations, vocab_levels)
        if not success:
            return
        # Level- und Stat-Variablen zurücksetzen
        self.level_var.set(f"Station 1: {self.stations[0]['name']}")
        # Erstes Poster und erste Frage
        poster.load_poster(self, self.level)
        fragenlogik.next_question(self)
