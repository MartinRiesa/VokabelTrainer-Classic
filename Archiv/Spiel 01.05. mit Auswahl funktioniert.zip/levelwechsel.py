"""
levelwechsel.py – steuert den Übergang zum nächsten Level mit Poster-, Karten- und Button-Logik.
"""

import poster
from stats_game import Stat
import fragenlogik
import uebersichtskarte                   # GEÄNDERT: richtiges Modul importiert
from hilfsfunktionen import geo_to_pixel
from config import MAP_SMALL, LAT_MIN, LAT_MAX, LON_MIN, LON_MAX
from tkinter import messagebox


def level_up(game):
    """
    Erhöht das Level, aktualisiert Pool und Statistiken,
    zeigt Poster, Minikarte und Übersichtskarte, danach den 'Quiz starten'-Button.
    """
    prev_index = game.level - 1
    game.level += 1

    # 1) Spielende prüfen
    if game.level > game.total_levels:
        messagebox.showinfo("Ende", "Alle Stationen geschafft!")
        game.root.quit()
        return

    # 2) Vokabel-Pool erweitern
    neue_vocab = game.vocab_levels[game.level - 1]
    game.vocab_pool += neue_vocab
    game.vocab = list(game.vocab_pool)

    # 3) Statistik zurücksetzen / neu aufbauen
    game.stats = {q: Stat() for q, _ in game.vocab_pool}
    game.streak = 0
    game.last_question = None

    # 4) Poster laden und GUI-Labels updaten
    poster.load_poster(game, game.level)
    station_name = game.stations[game.level - 1]['name']
    game.level_var.set(f"Station {game.level}: {station_name}")

    # Koordinaten aktualisieren
    lat, lon = game.stations[game.level - 1]['lat'], game.stations[game.level - 1]['lon']
    game.coord_var.set(f"{lat:.4f}, {lon:.4f}")

    # 5) Minikarte verschieben und in den Vordergrund heben
    w, h = MAP_SMALL
    x, y = geo_to_pixel(lat, lon, map_w=w, map_h=h)
    game.map_canvas.coords(game.marker, x, y)
    game.map_canvas.lift()  

    # 6) Übersichtskarte als modales Fenster anzeigen
    #    (blockiert, bis der Nutzer auf "Weiter" klickt)
    uebersichtskarte.show_overview(game)

    # 7) Nach Schließen der Übersicht: 'Quiz starten'-Button anzeigen
    game.start_btn.pack(pady=20)
