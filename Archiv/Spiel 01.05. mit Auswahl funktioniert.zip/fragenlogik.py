"""
fragenlogik.py – enthält Logik für Fragenstellung, Auswertung und Levelwechsel-Bedingung.
"""

import random
import datetime as dt
import poster
import levelwechsel
from config import SPACING_MIN


def next_question(game):
    for b in game.btns:
        b.state(["!disabled"])
        b.configure(style="TButton")
    game.next_btn.pack_forget()

    choices = [pair for pair in game.vocab_pool if pair[0] != game.last_question]
    if not choices:
        choices = game.vocab_pool

    q, a = random.choice(choices)
    game.last_question = q
    game.current_question, game.correct_answer = q, a

    stat = game.stats[q]
    opts = stat.wrong_choices.copy()
    pool_wrong = [x for _, x in game.vocab_pool if x != a and x not in opts]
    random.shuffle(pool_wrong)
    opts += pool_wrong[: max(0, 3 - len(opts))]
    opts.append(a)
    random.shuffle(opts)

    for btn, txt in zip(game.btns, opts):
        btn.config(text=txt)

    game.qvar.set(q)
    game.start_time = dt.datetime.now()


def evaluate(game, answer: str, btn):
    stat = game.stats[game.current_question]
    now = dt.datetime.now()

    if answer == game.correct_answer:
        game.streak += 1

        # Leitner-System aktualisieren
        stat.i = min(
            (0 if stat.n == 0 else (1 if stat.n == 1 else stat.i + 1)),
            len(SPACING_MIN) - 1
        )
        stat.n += 1
        stat.due = now + dt.timedelta(minutes=SPACING_MIN[stat.i])
        stat.wrong_choices.clear()

        # Level-Up, wenn alle Vokabeln des Levels einmal korrekt waren
        if game.streak >= len(game.vocab_levels[game.level - 1]):
            levelwechsel.level_up(game)
            return

        poster.update_blur(game)
        next_question(game)

    else:
        # Falsche Antwort markieren
        for b in game.btns:
            txt = b.cget("text")
            if txt == game.correct_answer:
                b.configure(style="Success.TButton")
            elif b is btn:
                b.configure(style="Danger.TButton")
            b.state(["disabled"])

        game.streak = 0
        stat.n = 0
        stat.i = 0
        stat.due = now + dt.timedelta(minutes=SPACING_MIN[0])
        stat.wrong_choices = [answer]

        poster.update_blur(game)
        game.next_btn.pack(pady=20)


def after_wrong(game):
    next_question(game)
