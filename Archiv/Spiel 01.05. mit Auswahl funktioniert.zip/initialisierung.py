"""
initialisierung.py – Laden der Spieldaten und Aufbau der grafischen Oberfläche zu Spielbeginn.
"""

import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

from config import (
    BASE_PATH,
    EXCEL_STATIONS,
    CSV_VOCAB,
    BANNER_W, BANNER_H,
    MAP_FILE, TRAIN_ICON,
    MAP_SMALL
)
from hilfsfunktionen import geo_to_pixel
import fragenlogik  # für start_btn


def load_game_data(learn_lang=None, native_lang=None):
    """
    Lädt die Stations- und Vokabeldaten aus den Excel-/CSV-Dateien.
    Optional werden learn_lang und native_lang entgegen genommen,
    um mit Mehrsprachigkeit kompatibel zu bleiben (derzeit ungenutzt).
    """
    # Stationen (Excel mit Header-Zeile)
    df_st = pd.read_excel(EXCEL_STATIONS, header=0)
    stations = []
    for _, row in df_st.iterrows():
        try:
            # Koordinaten in Excel stehen z.B. als 501096 → 50.1096
            lat = float(row['Latitude']) / 10000
            lon = float(row['Longitude']) / 10000
            name = str(row['Station'])
            stations.append({"name": name, "lat": lat, "lon": lon})
        except Exception:
            continue

    # Vokabeln (CSV mit ;-Trennzeichen)
    df_vocab = pd.read_csv(CSV_VOCAB, sep=';', usecols=[0, 1], header=0, encoding='utf-8-sig')
    vocab_pairs = list(zip(df_vocab.iloc[:, 0].astype(str),
                           df_vocab.iloc[:, 1].astype(str)))

    blocks = len(vocab_pairs) // 7
    total_levels = min(len(stations), blocks)
    stations = stations[:total_levels]
    vocab_levels = [vocab_pairs[i*7:(i+1)*7] for i in range(total_levels)]

    return stations, vocab_levels


def init_game_state(game, stations, vocab_levels):
    """
    Initialisiert den Spielzustand und den kumulativen Vokabel-Pool.
    """
    game.total_levels = len(vocab_levels)
    game.stations = stations
    game.vocab_levels = vocab_levels

    if not stations:
        messagebox.showerror("Fehler", "Keine Stationen gefunden.")
        game.root.quit()
        return False

    game.level = 1
    game.vocab_pool = list(vocab_levels[0])
    game.vocab = list(game.vocab_pool)

    from stats_game import Stat
    game.stats = {question: Stat() for question, _ in game.vocab_pool}
    game.streak = 0
    game.last_question = None

    return True


def build_ui(game):
    """
    Baut die GUI auf: Banner, Infozeile (mit Koordinaten), Quiz-Bereich, Minikarte.
    """
    # Fenster-Grundeinstellungen
    game.root.title("Vokabellernspiel – Deutschland-Reise")
    game.root.geometry("1024x860")
    game.root.configure(bg="#eef4fb")

    # Banner
    banner_frame = ttk.Frame(game.root, padding=10, style="Bg.TFrame")
    banner_frame.pack()
    game.canvas = tk.Canvas(banner_frame, width=BANNER_W, height=BANNER_H, highlightthickness=0)
    game.canvas.pack()
    game.poster_item = game.canvas.create_image(0, 0, anchor="nw")

    # Infozeile: Level, Station, Koordinaten
    info_frame = ttk.Frame(game.root, padding=5, style="Bg.TFrame")
    info_frame.pack()
    game.level_var = tk.StringVar(value=f"Station 1: {game.stations[0]['name']}")
    ttk.Label(info_frame, textvariable=game.level_var,
              font=("Arial", 14, "bold"), style="Bg.TLabel").pack(side="left", padx=12)

    game.coord_var = tk.StringVar(value=f"{game.stations[0]['lat']:.4f}, {game.stations[0]['lon']:.4f}")
    ttk.Label(info_frame, textvariable=game.coord_var,
              font=("Arial", 14), style="Bg.TLabel").pack(side="left", padx=12)

    # Quiz-Bereich
    play_frame = ttk.Frame(game.root, padding=10, style="Bg.TFrame")
    play_frame.pack(expand=True, fill="both")

    # Frage
    game.qvar = tk.StringVar()
    question_row = ttk.Frame(play_frame, style="Bg.TFrame")
    question_row.pack(pady=(30, 15))
    ttk.Label(question_row, textvariable=game.qvar,
              font=("Arial", 28, "bold"), style="Bg.TLabel").pack(side="left")
    from tts import speak_current_word
    speaker_btn = ttk.Button(question_row, text="🔊", width=3,
                             command=lambda: speak_current_word(game))
    speaker_btn.pack(side="left", padx=10)
    game.speaker_btn = speaker_btn

    # Antwort-Buttons
    game.btns = []
    for _ in range(4):
        btn = ttk.Button(play_frame, style="TButton")
        btn.configure(command=lambda b=btn: fragenlogik.evaluate(game, b.cget("text"), b))
        btn.pack(pady=8)
        game.btns.append(btn)

    # Weiter-Button bei falscher Antwort
    from fragenlogik import after_wrong
    game.next_btn = ttk.Button(play_frame, text="Weiter",
                               command=lambda: after_wrong(game))

    # Start-Button für das erste Quiz
    game.start_btn = ttk.Button(play_frame, text="Quiz starten",
                                command=lambda: (game.start_btn.pack_forget(),
                                                 fragenlogik.next_question(game)))
    game.start_btn.pack(pady=8)

    # Minikarte
    w_small, h_small = MAP_SMALL
    game.map_canvas = tk.Canvas(game.root, width=w_small, height=h_small,
                                highlightthickness=1, bd=1)
    game.map_canvas.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-10)

    game.map_tk = ImageTk.PhotoImage(
        Image.open(MAP_FILE).resize((w_small, h_small), Image.LANCZOS),
        master=game.root
    )
    game.map_canvas.create_image(0, 0, anchor="nw", image=game.map_tk)

    game.train_tk = ImageTk.PhotoImage(
        Image.open(TRAIN_ICON).convert("RGBA").resize((24, 24), Image.LANCZOS),
        master=game.root
    )
    x0, y0 = geo_to_pixel(game.stations[0]['lat'], game.stations[0]['lon'],
                          map_w=w_small, map_h=h_small)
    game.marker = game.map_canvas.create_image(x0, y0, anchor="center", image=game.train_tk)
