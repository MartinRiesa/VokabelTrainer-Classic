# poster.py

from config import BANNER_W, BANNER_H
from poster_loader import load_poster_image, display_poster
from poster_effects import blur_image, sharpen_image
from PIL import Image, ImageTk
import os

def load_poster(game, level):
    """
    Lädt und zeigt das Poster für das gegebene Level.
    Erwartet Dateien im gleichen Ordner wie poster.py namens '1.jpg', '2.jpg', etc.
    Fällt auf den grauen Placeholder zurück, wenn die Datei fehlt.
    """
    # Verzeichnis ermitteln, in dem poster.py liegt
    base_dir = os.path.dirname(__file__)
    poster_jpg = os.path.join(base_dir, f"{level}.jpg")

    if os.path.isfile(poster_jpg):
        try:
            photo = load_poster_image(poster_jpg, (BANNER_W, BANNER_H))
            display_poster(game, photo)
            return
        except Exception:
            pass

    # Fallback: grauer Platzhalter mit Hinweis
    game.canvas.delete("all")
    game.canvas.configure(bg="#ccc")
    game.canvas.create_text(
        BANNER_W // 2, BANNER_H // 2,
        text=f"Kein Poster für Level {level}",
        font=("Arial", 24), fill="#666"
    )
    # Neues poster_item für künftige Updates anlegen
    game.poster_item = game.canvas.create_image(0, 0, anchor="nw")


def update_blur(game, radius=10):
    """
    Wendet Blur aufs aktuelle Poster an. Fällt zurück, wenn kein JPEG existiert.
    """
    import os
    base_dir = os.path.dirname(__file__)
    poster_jpg = os.path.join(base_dir, f"{game.level}.jpg")
    if not os.path.isfile(poster_jpg):
        return

    try:
        pil_img = Image.open(poster_jpg).resize((BANNER_W, BANNER_H), Image.LANCZOS)
        blurred = blur_image(pil_img, radius)
        blurred_photo = ImageTk.PhotoImage(blurred)
        display_poster(game, blurred_photo)
    except Exception:
        pass


def update_sharpen(game):
    """
    Wendet Schärfen aufs aktuelle Poster an. Fällt zurück, wenn kein JPEG existiert.
    """
    import os
    base_dir = os.path.dirname(__file__)
    poster_jpg = os.path.join(base_dir, f"{game.level}.jpg")
    if not os.path.isfile(poster_jpg):
        return

    try:
        pil_img = Image.open(poster_jpg).resize((BANNER_W, BANNER_H), Image.LANCZOS)
        sharp = sharpen_image(pil_img)
        sharp_photo = ImageTk.PhotoImage(sharp)
        display_poster(game, sharp_photo)
    except Exception:
        pass
